import java.util.NoSuchElementException;

//ArrayStack gaan wuxu leyahay startsize oo manual ah
//haduu full noqdo si automatic buu isku kordhinayyaa
public class smartStack<B> {
    private B[] data;
    private int topIndex;
    private static final int StartSize = 3;
    public smartStack() {
        data = (B[]) (new Object[StartSize]);
        topIndex = -1;
    }
    public void push(B value) {
        if (isFull()) {
            expandManually();
        }
        data[++topIndex] = value;
    }
    public B pop() {
        if (isEmpty()) {
            throw new NoSuchElementException("Stack is full.");
        }
        B temp = data[topIndex];
        data[topIndex] = null;
        topIndex--;
        return temp;
    }
    public B peek() {
        if (isEmpty()) {
            throw new NoSuchElementException("Stack is full.");
        }
        return data[topIndex];
    }
    public int size() {
        return topIndex;
    }
    public boolean isEmpty() {
        return topIndex == -1;
    }
    private boolean isFull() {
        return topIndex == data.length - 1;
    }
    private void expandManually() {
        int newSize = data.length * 2;
        B[] biggerArray = (B[]) (new Object[newSize]);
        for (int i = 0; i <= topIndex; i++) {
            biggerArray[i] = data[i];
        }
        data = biggerArray;
    }
    public void showStack() {
        if (isEmpty()) {
            throw new NoSuchElementException("Stack is empty.");
        }
        System.out.println("Stack contents");
        for (int i = 0; i <= topIndex; i++) {
            System.out.println(data[i]);
        }
        System.out.println();
    }
}
