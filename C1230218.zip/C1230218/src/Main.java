public class Main {
    public static void main(String[] args) {
        smartStack<Integer> s1 = new smartStack<>();
        s1.push(1);
        s1.push(2);
        s1.push(3);
        s1.push(4);
        s1.push(5);
        s1.showStack();
        System.out.println("isEmpty method");
        System.out.println(s1.isEmpty());
        s1.pop();//POP METHOD: Removes the top element
        System.out.println("peek method");
        System.out.println(s1.peek());
        System.out.println("size method");
        System.out.println(s1.size());
        System.out.println("Final Display");
        s1.showStack();
    }
}
